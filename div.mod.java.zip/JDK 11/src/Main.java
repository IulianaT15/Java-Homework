public class Main {
    public static void main(String[] args) {
        int n, a, b, c;
        n = 345;
        a = n / 100;
        b = (n / 10) % 10;
        c = n % 10;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

    }
    }