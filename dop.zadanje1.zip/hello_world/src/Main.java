public class Main {
    public static void main(String[] args) {
     int i= 2147483647;
     System.out.println(i);
     int i1= 2147483647 + 1;
     System.out.println(i1);






    }
}