public class Main {
    public static void main(String[] args) {
        char myLetter = 'G';
        int myNum = 89;
        byte myByte = 4;
        short myShort = 56;
        float myFloatNum = 4.7333436f;
        double myDouble = 4.355453532d;
        long myLong = 12_121L;
        System.out.println(myLetter);
        System.out.println(myNum);
        System.out.println(myByte);
        System.out.println(myShort);
        System.out.println(myFloatNum);
        System.out.println(myDouble);
        System.out.println(myLong);





    }
}